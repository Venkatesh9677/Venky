Thank you for downloading and using our projects!! Stay connected and Keep supporting us by sharing it with your friends,family and all who needs it. Happy Learning! :)

**************************************[Genie Projects World]********************************************

Project Name: Hotel Management System

Developed By: GPW Team

Summary: This project is designed to help admin to maintain and keep track of info about rooms and working staffs in the hotel. Here the admin has all the privileges and can view/add/edit/remove rooms info and also staffs info. Here the admin can view a summary of Total rooms, Booked rooms, Available rooms, Checked-in rooms, Customer complaints, Staffs, Total pending payments, Balance Payments, Total earnings. In statistics page, admin can view additional info about Employees percentage based on their roles, Hotel expenses, Reserved rooms count in day-wise graph.    
 
Technologies Used: HTML, CSS, JavaScript, AJAX for frontend, PHP as a backend and MySQL for the database.

Features:
-->Simple and elegant UI
-->User-Friendly Interface
-->Easy to add, edit or remove the rooms,staffs
-->Visual dashboard with summary
-->Provides all rooms info at one place: room no, room type, booking status, check in & check out status.
-->Easy to register new staffs and update profile info for existing staffs.
-->Contains all essential functionalities
-->Inbuilt hashing mechanism
-->Fully customizable
-->Compact in size

IMPORTANT NOTE: Use only for Educational Purposes!

******************************************************************************************************

Check our channel for more Projects!
