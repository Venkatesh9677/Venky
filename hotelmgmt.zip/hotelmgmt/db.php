<?php

$connection = mysqli_connect("localhost","root","","hotel_mgmt_db");